QUANTA - Android App Project

এই প্যাকেজে আপনার দেওয়া Quanta.html-কে Android WebView অ্যাপের ভেতরে রাখা হয়েছে।
Timer, Subjects, Tasks, Progress এবং Settings-এর মূল HTML/JavaScript অপরিবর্তিত রাখা হয়েছে।

APK তৈরি করার নিয়ম:
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. Android Studio থেকে এই QuantaAndroid ফোল্ডারটি Open করুন।
3. Gradle Sync শেষ হতে দিন। Android SDK Platform 35 এবং JDK 17 ইনস্টল থাকতে হবে।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) নির্বাচন করুন।
5. APK পাবেন: app/build/outputs/apk/debug/app-debug.apk

অ্যাপ ID: com.quanta.studytracker
ন্যূনতম Android: 6.0 (API 23)
ডেটা: WebView Local Storage-এ ডিভাইসেই সংরক্ষিত হয়। অ্যাপের ডেটা Clear/Uninstall করলে সংরক্ষিত পড়াশোনার রেকর্ড মুছে যেতে পারে।

নোট: এই পরিবেশে Android SDK/Gradle build tool নেই এবং বাইরের নেটওয়ার্কে প্রবেশ করা যাচ্ছে না। তাই এখানে সরাসরি APK compile করা সম্ভব হয়নি। এটি Android Studio-তে build করার সম্পূর্ণ source project।
